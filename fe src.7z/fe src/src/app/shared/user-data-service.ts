import { Injectable } from "@angular/core";

@Injectable()
export class UserDataService{
    userInfo:any;
}