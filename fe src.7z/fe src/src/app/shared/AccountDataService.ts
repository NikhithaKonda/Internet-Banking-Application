import { Injectable } from "@angular/core";
import { Account } from "../account/account";

@Injectable()
export class AccountDataService {
   accountData!: Account
}