export enum UserType {
   ADMIN = "ADMIN",
   CUSTOMER = "CUSTOMER"
}