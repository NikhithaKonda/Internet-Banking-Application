import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-transaction',
  templateUrl: './edit-transaction.component.html',
  styleUrls: ['./edit-transaction.component.css']
})
export class EditTransactionComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
