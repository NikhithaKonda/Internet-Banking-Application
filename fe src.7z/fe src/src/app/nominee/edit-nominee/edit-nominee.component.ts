import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-nominee',
  templateUrl: './edit-nominee.component.html',
  styleUrls: ['./edit-nominee.component.css']
})
export class EditNomineeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
