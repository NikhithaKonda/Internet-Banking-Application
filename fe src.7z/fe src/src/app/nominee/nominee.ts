export interface Nominee {
    nomineeId: number,
    nomineeName : string,
    govtId: string,
    govtIdType : string,
    phoneNo: number,
    relation : string
}
