import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-nominee',
  templateUrl: './view-nominee.component.html',
  styleUrls: ['./view-nominee.component.css']
})
export class ViewNomineeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
