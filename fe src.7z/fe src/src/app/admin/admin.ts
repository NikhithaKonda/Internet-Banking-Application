export interface Admin {
    
    userId: number,
    username:string,
    password:string,
    type: string,
    adminName:string,
    adminContact:string,
    adminEmailId:string
}