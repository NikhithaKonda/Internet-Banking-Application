import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-customers-list',
  templateUrl: './admin-customers-list.component.html',
  styleUrls: ['./admin-customers-list.component.css']
})
export class AdminCustomersListComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
