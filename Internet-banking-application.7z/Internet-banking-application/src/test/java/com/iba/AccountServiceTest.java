package com.iba;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;

import com.iba.pojo.AccountPojo;
import com.iba.pojo.SavingAccountPojo;
import com.iba.pojo.TransactionPojo;
import com.iba.repository.AccountRepository;

import com.iba.service.AccountService;
import com.iba.service.AccountServiceImpl;


public class AccountServiceTest {
	
	@InjectMocks
	AccountService accountService= new AccountServiceImpl();
	
	@Mock
	AccountRepository accountRepository;
	
	@Test
	public void testListAllAccounts() {
		
		List<AccountPojo> AccountPojoList = new ArrayList<AccountPojo>();
		AccountPojo accountPojo = new AccountPojo();
		List<TransactionPojo> transactionPojoList = new ArrayList<TransactionPojo>();
		TransactionPojo transactionPojo = new TransactionPojo();
		
		accountPojo.setAccountId(100);
		accountPojo.setBalance(10000.0);
		transactionPojo.setAmount(1000.0);
		transactionPojo.setTransactionId(100);
		transactionPojoList.add(transactionPojo);
		
		accountPojo.setTransactions(transactionPojoList);
		AccountPojoList.add(accountPojo);
		
		accountService = mock(AccountService.class, Mockito.RETURNS_DEEP_STUBS);
		
		Mockito.when(accountService.listAllAccounts()).thenReturn(AccountPojoList);
		
		assertEquals(1000.0, accountService.listAllAccounts().get(0).getTransactions().get(0).getAmount());
	}

	@Test
	public void testGetAccount() {
		
	
		AccountPojo accountPojo = new AccountPojo();
		List<TransactionPojo> transactionPojoList = new ArrayList<TransactionPojo>();
		TransactionPojo transactionPojo = new TransactionPojo();
		
		accountPojo.setAccountId(100);
		accountPojo.setBalance(10000.0);
		transactionPojo.setAmount(1000.0);
		transactionPojo.setTransactionId(100);
		transactionPojoList.add(transactionPojo);
		
		accountPojo.setTransactions(transactionPojoList);

		
		accountService = mock(AccountService.class, Mockito.RETURNS_DEEP_STUBS);
		
		Mockito.when(accountService.getAccount(100)).thenReturn(accountPojo);
		
		assertEquals(1000.0, accountService.getAccount(100).getTransactions().get(0).getAmount());
	}

	@Test
	public void testAddSavingsAccount() {
		
		
		SavingAccountPojo accountPojo = new SavingAccountPojo();
		List<TransactionPojo> transactionPojoList = new ArrayList<TransactionPojo>();
		TransactionPojo transactionPojo = new TransactionPojo();
		
		accountPojo.setAccountId(100);
		accountPojo.setBalance(10000.0);
		transactionPojo.setAmount(1000.0);
		transactionPojo.setTransactionId(1000);
		transactionPojoList.add(transactionPojo);
		
		accountPojo.setTransactions(transactionPojoList);
		
		
		accountService = mock(AccountService.class, Mockito.RETURNS_DEEP_STUBS);
		
		Mockito.when(accountService.addSavingsAccount(accountPojo)).thenReturn(accountPojo);
		
		assertEquals(1000, accountService.addSavingsAccount(accountPojo).getTransactions().get(0).getTransactionId());
	}

	@Test
	public void testUpdateSavingsAccount() {
		
		
		SavingAccountPojo accountPojo = new SavingAccountPojo();
		List<TransactionPojo> transactionPojoList = new ArrayList<TransactionPojo>();
		TransactionPojo transactionPojo = new TransactionPojo();
		
		accountPojo.setAccountId(100);
		accountPojo.setBalance(10000.0);
		transactionPojo.setAmount(1000.0);
		transactionPojo.setTransactionId(123);
		transactionPojoList.add(transactionPojo);
		
		accountPojo.setTransactions(transactionPojoList);
		
		
		accountService = mock(AccountService.class, Mockito.RETURNS_DEEP_STUBS);
		
		Mockito.when(accountService.updateSavingAccount(accountPojo)).thenReturn(accountPojo);
		
		assertEquals(123, accountService.updateSavingAccount(accountPojo).getTransactions().get(0).getTransactionId());
	}
}
