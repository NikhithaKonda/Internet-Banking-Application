package com.iba;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.mock;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.BeanUtils;

import com.iba.entity.AdminEntity;
import com.iba.entity.CustomerEntity;
import com.iba.exception.CustomerNotFoundException;
import com.iba.pojo.AdminPojo;
import com.iba.pojo.CustomerPojo;
import com.iba.repository.AdminRepository;
import com.iba.service.AdminService;
import com.iba.service.AdminServiceImpl;


public class AdminServiceTest {
	@InjectMocks
	AdminService adminService= new AdminServiceImpl();
	
	@Mock
	AdminRepository adminRepository;
	
	@Test
	public void TestAddAdmin() {
		
		AdminPojo adminPojo = new AdminPojo();
		AdminEntity adminEntity = new AdminEntity();
		
		adminPojo.setAdminName("karthik");
		
		adminEntity.setAdminName("kedam");
		
		
		AdminService adminService = mock(AdminService.class, Mockito.RETURNS_DEEP_STUBS);
		
		Mockito.when(adminService.addAdmin(adminPojo)).thenReturn(adminPojo);
		
		assertEquals("karthik", adminService.addAdmin(adminPojo).getAdminName());
		
	}

	@Test
	public void TestUpdateAdmin() {
		
		AdminPojo adminPojo = new AdminPojo();
		AdminEntity adminEntity = new AdminEntity();
		
		adminPojo.setAdminName("karthik");
		adminPojo.setAdminContact("1231231211");
		adminPojo.setUserId(100);
		
		adminEntity.setAdminName("kedam");
				
		AdminService adminService = mock(AdminService.class, Mockito.RETURNS_DEEP_STUBS);
		
		Mockito.when(adminService.updateAdmin(adminPojo)).thenReturn(adminPojo);
		
		assertEquals("karthik", adminService.updateAdmin(adminPojo).getAdminName());
		
	}
	
	@Test
	public void testDeleteCustomer() {
		AdminPojo adminPojo = new AdminPojo();
		adminPojo.setAdminName("karthik");
		adminPojo.setAdminContact("1231231211");
		adminPojo.setUserId(100);
		
		AdminService adminService = mock(AdminService.class, Mockito.RETURNS_DEEP_STUBS);
		
		Mockito.doReturn(true).when(adminService).removeAdmin(100);
		adminService.removeAdmin(100);
		
		assertEquals(true, adminService.removeAdmin(100));
	}
	
	@Test
	public void testGetCustomer() {
		
			
		AdminPojo adminPojo = new AdminPojo();
		adminPojo.setAdminName("karthik");
		adminPojo.setAdminContact("1231231211");
		adminPojo.setUserId(100);
		
		AdminService adminService = mock(AdminService.class, Mockito.RETURNS_DEEP_STUBS);
		
		Mockito.when(adminService.findAdminById(100)).thenReturn(adminPojo);
		
		assertEquals("karthik", adminService.findAdminById(100).getAdminName());
	}
	

}
