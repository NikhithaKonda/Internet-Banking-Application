//package com.iba;
//
//import static org.junit.jupiter.api.Assertions.assertEquals;
//import static org.junit.jupiter.api.Assertions.assertNotEquals;
//import static org.mockito.Mockito.mock;
//
//import java.util.ArrayList;
//import java.util.List;
//import java.util.Optional;
//
//import org.junit.jupiter.api.Test;
//import org.mockito.InjectMocks;
//import org.mockito.Mock;
//import org.mockito.Mockito;
//
//import com.iba.entity.BeneficiaryEntity;
//import com.iba.entity.CustomerEntity;
//import com.iba.pojo.BeneficiaryPojo;
//import com.iba.pojo.CustomerPojo;
//import com.iba.repository.AdminRepository;
//import com.iba.repository.BeneficiaryRepository;
//import com.iba.service.AdminService;
//import com.iba.service.AdminServiceImpl;
//import com.iba.service.BeneficiaryService;
//import com.iba.service.BeneficiaryServiceImpl;
//
//public class BeneficiaryServiceTest {
//	
//	@InjectMocks
//	BeneficiaryService beneficiaryService= new BeneficiaryServiceImpl();
//	
//	@Mock
//	BeneficiaryRepository beneficiaryRepository;
//	
//	@Test
//	public void testGetCustomer() {
//		
//		
//		BeneficiaryPojo mockArgumentCustomer = new BeneficiaryPojo();
//		mockArgumentCustomer.setBeneficiaryId(101);
//		mockArgumentCustomer.setBeneficiaryAccountNumber(10001);
//		mockArgumentCustomer.setBeneficiaryName("maria");
//		mockArgumentCustomer.setAccountType("savings");
//		
//		beneficiaryService = mock(BeneficiaryService.class, Mockito.RETURNS_DEEP_STUBS);
//		
//		Mockito.when(beneficiaryService.findBeneficiaryById(101)).thenReturn(mockArgumentCustomer);
//		
//		assertNotEquals("maria", beneficiaryService.findBeneficiaryById(100).getBeneficiaryName());
//	}
//
//	@Test
//	public void testAddBeneficiary() {
//		
//		
//		BeneficiaryPojo mockArgumentCustomer = new BeneficiaryPojo();
//		mockArgumentCustomer.setBeneficiaryId(101);
//		mockArgumentCustomer.setBeneficiaryAccountNumber(10001);
//		mockArgumentCustomer.setBeneficiaryName("maria");
//		mockArgumentCustomer.setAccountType("savings");
//		
//		beneficiaryService = mock(BeneficiaryService.class, Mockito.RETURNS_DEEP_STUBS);
//		
//		Mockito.when(beneficiaryService.addBeneficiary(mockArgumentCustomer)).thenReturn(mockArgumentCustomer);
//		
//		assertNotEquals("karthik", beneficiaryService.addBeneficiary(mockArgumentCustomer).getBeneficiaryName());
//	}
//
//	
//	@Test
//	public void testListAllBeneficiaries() {
//		
//		List<BeneficiaryPojo> beneficiaryPojos = new ArrayList<BeneficiaryPojo>();
//		
//		BeneficiaryPojo mockArgumentCustomer = new BeneficiaryPojo();
//		mockArgumentCustomer.setBeneficiaryId(101);
//		mockArgumentCustomer.setBeneficiaryAccountNumber(10001);
//		mockArgumentCustomer.setBeneficiaryName("maria");
//		mockArgumentCustomer.setAccountType("savings");
//		
//		beneficiaryPojos.add(mockArgumentCustomer);
//		
//		beneficiaryService = mock(BeneficiaryService.class, Mockito.RETURNS_DEEP_STUBS);
//		
//		Mockito.when(beneficiaryService.listAllBeneficiaries()).thenReturn(beneficiaryPojos);
//		
//		assertEquals(1, beneficiaryService.listAllBeneficiaries().size());
//	}
//
//	@Test
//	public void testDeleteBeneficiary() {
//		
//		
//		beneficiaryService = mock(BeneficiaryService.class, Mockito.RETURNS_DEEP_STUBS);
//		
//		Mockito.when(beneficiaryService.deleteBeneficiary(100)).thenReturn(true);
//		
//		assertEquals(true, beneficiaryService.deleteBeneficiary(100));
//	}
//	
//	@Test
//	public void testUpdateBeneficiary() {
//		
//		
//		BeneficiaryPojo mockArgumentCustomer = new BeneficiaryPojo();
//		mockArgumentCustomer.setBeneficiaryId(101);
//		mockArgumentCustomer.setBeneficiaryAccountNumber(10001);
//		mockArgumentCustomer.setBeneficiaryName("maria");
//		mockArgumentCustomer.setAccountType("savings");
//		
//		beneficiaryService = mock(BeneficiaryService.class, Mockito.RETURNS_DEEP_STUBS);
//		
//		Mockito.when(beneficiaryService.updateBeneficiary(mockArgumentCustomer)).thenReturn(mockArgumentCustomer);
//		
//		assertEquals("maria", beneficiaryService.updateBeneficiary(mockArgumentCustomer).getBeneficiaryName());
//	}
//
//}
