package com.iba.entity;

import com.iba.pojo.UserPojo;

public class AuthResponce {
	private final String jwt;

	private UserPojo user;

	public AuthResponce(String jwt, UserPojo user) {
		super();
		this.jwt = jwt;
		this.user = user;
	}

	public UserPojo getUser() {
		return user;
	}

	public void setUser(UserPojo user) {
		this.user = user;
	}

	public String getJwt() {
		return jwt;
	}

	@Override
	public String toString() {
		return "AuthResponce [jwt=" + jwt + ", user=" + user + "]";
	}

}
