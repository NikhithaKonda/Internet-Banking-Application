package com.iba.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name = "beneficiary")
public class BeneficiaryEntity {
	@Id
	@Column(name = "BENEFICIARY_ID")
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	private long beneficiaryId;

	@Column(name = "BENEFICIARY_NAME")
	private String beneficiaryName;

	@Column(name = "BENEFICIARY_ACCOUNT_NO")
	private long beneficiaryAccountNumber;

	@Column(name = "IFSC")
	private String ifsc;

	@Column(name = "ACCOUNT_TYPE")
	private String accountType;

	@Column(name = "is_active")
	private int isActive;

	@ManyToOne
	@JoinColumn(name = "ACCOUNT_ID")
	@JsonBackReference
//	@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
	private AccountEntity account;

	public BeneficiaryEntity() {
		super();
	}

	public BeneficiaryEntity(long beneficiaryId, String beneficiaryName, long beneficiaryAccountNumber, String ifsc,
			String accountType, int isActive, AccountEntity account) {
		super();
		this.beneficiaryId = beneficiaryId;
		this.beneficiaryName = beneficiaryName;
		this.beneficiaryAccountNumber = beneficiaryAccountNumber;
		this.ifsc = ifsc;
		this.accountType = accountType;
		this.isActive = isActive;
		this.account = account;
	}

	public int getIsActive() {
		return isActive;
	}

	public void setIsActive(int isActive) {
		this.isActive = isActive;
	}

	public long getBeneficiaryId() {
		return beneficiaryId;
	}

	public void setBeneficiaryId(long beneficiaryId) {
		this.beneficiaryId = beneficiaryId;
	}

	public String getBeneficiaryName() {
		return beneficiaryName;
	}

	public void setBeneficiaryName(String beneficiaryName) {
		this.beneficiaryName = beneficiaryName;
	}

	public long getBeneficiaryAccountNumber() {
		return beneficiaryAccountNumber;
	}

	public void setBeneficiaryAccountNumber(long beneficiaryAccountNumber) {
		this.beneficiaryAccountNumber = beneficiaryAccountNumber;
	}

	public String getIfsc() {
		return ifsc;
	}

	public void setIfsc(String ifsc) {
		this.ifsc = ifsc;
	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	public AccountEntity getAccount() {
		return account;
	}

	public void setAccount(AccountEntity account) {
		this.account = account;
	}

	@Override
	public String toString() {
		return "BeneficiaryEntity [beneficiaryId=" + beneficiaryId + ", beneficiaryName=" + beneficiaryName
				+ ", beneficiaryAccountNumber=" + beneficiaryAccountNumber + ", ifsc=" + ifsc + ", accountType="
				+ accountType + "]";
	}

}
