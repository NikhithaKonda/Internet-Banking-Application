package com.iba.entity;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

@Entity
@DiscriminatorValue("2")
public class TermAccountEntity extends AccountEntity {

	@Column(name = "AMOUNT")
	private double amount;

	@Column(name = "MONTHS")
	private int months;

	@Column(name = "PENALTY_AMOUNT")
	private double penaltyAmount;

	public TermAccountEntity() {
		super();
		// TODO Auto-generated constructor stub
	}

	public TermAccountEntity(long accountId, double interestRate, double balance, String dateOfJoining, long customer,
			int isActive, int accountType, List<BeneficiaryEntity> beneficiaries, List<TransactionEntity> transactions,
			List<NomineeEntity> nominees, double amount, int months, double penaltyAmount) {
		super(accountId, interestRate, balance, dateOfJoining, customer, isActive, accountType, beneficiaries,
				transactions, nominees);
		this.amount = amount;
		this.months = months;
		this.penaltyAmount = penaltyAmount;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	public int getMonths() {
		return months;
	}

	public void setMonths(int months) {
		this.months = months;
	}

	public double getPenaltyAmount() {
		return penaltyAmount;
	}

	public void setPenaltyAmount(double penaltyAmount) {
		this.penaltyAmount = penaltyAmount;
	}

	@Override
	public String toString() {
		return "TermAccountEntity [amount=" + amount + ", months=" + months + ", penaltyAmount=" + penaltyAmount + "]";
	}

}
