package com.iba.service;

import java.util.List;

import javax.validation.Valid;

import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;

import com.iba.entity.UserEntity;
import com.iba.pojo.UserPojo;

public interface UserSevice extends UserDetailsService {
	
	public UserDetails loadUserByUsername(String username);
	public UserEntity saveUser(UserPojo user);

	public List<UserPojo> ListAllUsers();
	public UserPojo addNewUser(UserPojo user) ;
	public boolean signIn(long userid,  String password);
	public UserEntity signOut(UserEntity user) ;
	public UserPojo updateUserInfo( UserPojo user) ;	
	public UserPojo getUserById(long userId);
	public UserEntity getByUserName(String username);

}
