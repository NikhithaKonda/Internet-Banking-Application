package com.iba.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.iba.entity.UserEntity;
import com.iba.exception.UserNotFoundException;
import com.iba.pojo.AdminPojo;
import com.iba.pojo.UserPojo;
import com.iba.repository.UserRepository;

@Service
public class UserServiceImpl implements UserSevice, UserDetailsService {

	@Autowired
	public UserRepository userRepository;
	
	@Autowired
	private PasswordEncoder bcryptEncoder;
	
	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		
		UserEntity user = userRepository.findByUserName(username);
		System.out.println("in load service " +user);
		
		return new User(user.getUsername(), user.getPassword(), new ArrayList<>());
	}
	
	public UserEntity saveUser(UserPojo user) {
		
		
		
		UserEntity userEntity = new UserEntity();
		
		userEntity.setUsername(user.getUsername());
		String password = user.getPassword();
		
		String hashedPassword = bcryptEncoder.encode(password);
		
		userEntity.setPassword(hashedPassword);
		
		userEntity.setType(user.getType());
		
		System.out.println(userEntity);
		
		return userRepository.save(userEntity);
	}

	@Override
	public UserPojo addNewUser(UserPojo user) {

		UserEntity entity = new UserEntity();

		BeanUtils.copyProperties(user, entity);

		UserEntity ue = userRepository.save(entity);

		BeanUtils.copyProperties(ue, user);

		return user;

	}

	@Override
	public boolean signIn(long userId, String password) {

		System.out.println(userId + " " + password);
		Optional<UserEntity> userEntity = userRepository.findById(userId);
		
		String pass = userEntity.get().getPassword();
		
		if (userEntity.isPresent() == false) {
			throw new UserNotFoundException("User Not Found with ID!");
		}

		if (pass.equals(password)) {
			return true;
		}
		return false;
	}

	@Override
	public UserEntity signOut(UserEntity user) {
		return user;
	}

	@Override
	public UserPojo updateUserInfo(UserPojo user) {
		UserEntity entity = new UserEntity();

		BeanUtils.copyProperties(user, entity);

		UserEntity ue = userRepository.save(entity);

		BeanUtils.copyProperties(ue, user);

		return user;
	}

	@Override
	public List<UserPojo> ListAllUsers() {

		List<UserEntity> user = userRepository.findAll();

		List<UserPojo> userPojos = new ArrayList<UserPojo>();

		for (UserEntity entity : user) {
			UserPojo up = new UserPojo();

			BeanUtils.copyProperties(entity, up);

			userPojos.add(up);

		}

		return userPojos;

	}

	@Override
	public UserPojo getUserById(long userId) {

		Optional<UserEntity> user = userRepository.findById(userId);

		if (user.isPresent() == false) {
			throw new UserNotFoundException("User Not Found with ID!");
		}

		UserEntity entity = user.get();
		UserPojo pojo = new AdminPojo();
		BeanUtils.copyProperties(entity, pojo);

		return pojo;
	}

	@Override
	public UserEntity getByUserName(String username) {
		
		return userRepository.findByUserName(username);
	}
	

}
