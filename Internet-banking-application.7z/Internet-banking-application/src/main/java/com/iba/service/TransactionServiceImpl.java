package com.iba.service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import javax.transaction.Transactional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.stereotype.Service;

import com.iba.entity.AccountEntity;
import com.iba.entity.BeneficiaryEntity;
import com.iba.entity.SavingAccountEntity;
import com.iba.entity.TransactionEntity;
import com.iba.exception.AccountNotFoundException;
import com.iba.exception.NoBalanceException;
import com.iba.exception.TransactionNotFoundException;
import com.iba.pojo.AccountPojo;
import com.iba.pojo.SavingAccountPojo;
import com.iba.pojo.TransactionPojo;
import com.iba.repository.SavingAccountRepository;
import com.iba.repository.TransactionRepository;

@Service
@Transactional
public class TransactionServiceImpl implements TransactionService {

	@Autowired
	TransactionRepository transactionRepository;
	
	@Autowired
	private AuthenticationManager authenticationManager;
	
	@Autowired
	private SavingAccountRepository savingAccountRepository;

	@Override
	public TransactionPojo createTransaction(TransactionPojo transaction) throws Exception{

//		TransactionEntity transactionEntity = new TransactionEntity();
//
//		AccountPojo accountPojo = transaction.getAccount();
//
//		AccountEntity accountEntity = new AccountEntity();
//
//		BeanUtils.copyProperties(accountPojo, accountEntity);
//
//		BeanUtils.copyProperties(transaction, transactionEntity);
//
//		transactionEntity.setAccount(accountEntity);
//
//		TransactionEntity newEntity = transactionRepository.save(transactionEntity);
//
//		BeanUtils.copyProperties(newEntity, transaction);
		
			
			String username = transaction.getUsername();
			String password = transaction.getPassword();
			
			long accountId = transaction.getAccount().getAccountId();
			BeneficiaryEntity beneficiaryEntity = transaction.getBeneficiary();
						
			
			Optional<SavingAccountEntity> accountEntityOptional = savingAccountRepository.findById(accountId);
			if (accountEntityOptional.isPresent() == false) {
				throw new AccountNotFoundException("Account with ID:" + accountId + " not found!");
			}
			if (accountEntityOptional.isPresent() == false) {
				throw new AccountNotFoundException("Account with ID:" + accountId + " not found!");
			}
			
			System.out.println( username + " " + password);
			try {
				authenticationManager.authenticate(
						new UsernamePasswordAuthenticationToken(username, password)
						);			
			} catch(BadCredentialsException e) {
				throw new Exception("Incorrect username or password!", e);
			}catch(Exception e) {
				throw new Exception("auth manager failed!" + e);
			}


				SavingAccountEntity accountEntity = accountEntityOptional.get();
				
				
				double balance = accountEntity.getBalance();
				
				double amount = transaction.getAmount();
				System.out.println(accountEntity.getMinBalance());
				if (balance - amount < accountEntity.getMinBalance()) {
					throw new NoBalanceException("Insufficent balance to proceed to transaction!");
				}
				
				accountEntity.setBalance(balance - amount);
				
				TransactionEntity transactionEntity = new TransactionEntity();
				
				BeanUtils.copyProperties(transaction, transactionEntity);
				
				transactionEntity.setAccount(accountEntity);
				transactionEntity.setBeneficiary(beneficiaryEntity);
				transactionEntity.setTransactionType("Transfer");
				transactionEntity.setTransactionStatus("success!");
				transactionEntity.setTransactionRemarks("Transfer Successful!");
				TransactionEntity newEntity = transactionRepository.save(transactionEntity);

				BeanUtils.copyProperties(newEntity, transaction);

		return transaction;
			
		
	}

	@Override
	public TransactionPojo viewTransaction(long transactionId) {

		TransactionEntity transactionEntity = transactionRepository.getById(transactionId);

		TransactionPojo transactionPojo = new TransactionPojo();

		BeanUtils.copyProperties(transactionEntity, transactionPojo);

		return transactionPojo;

	}

	@Override
	public TransactionPojo findTransactionById(long transactionId) {

		TransactionEntity transactionEntity = transactionRepository.getById(transactionId);

		AccountEntity accountEntity = transactionEntity.getAccount();
		TransactionPojo transactionPojo = new TransactionPojo();

		AccountPojo accountPojo = new AccountPojo();			
		BeanUtils.copyProperties(accountEntity, accountPojo);

		BeanUtils.copyProperties(transactionEntity, transactionPojo);
		transactionPojo.setAccount(accountPojo);

		return transactionPojo;
	}

	@Override
	public List<TransactionPojo> listAllTransactions() {

		List<TransactionEntity> transactionEntities = transactionRepository.findAll();

		if (transactionEntities.isEmpty()) {
			throw new TransactionNotFoundException("No transactions found!");
		}

		List<TransactionPojo> transactionPojos = new ArrayList<TransactionPojo>();

		for (TransactionEntity transactionEntity : transactionEntities) {
			TransactionPojo transactionPojo = new TransactionPojo();

			AccountEntity accountEntity = transactionEntity.getAccount();
			AccountPojo accountPojo = new AccountPojo();			
			BeanUtils.copyProperties(accountEntity, accountPojo);

			BeanUtils.copyProperties(transactionEntity, transactionPojo);
			transactionPojo.setAccount(accountPojo);

			transactionPojos.add(transactionPojo);
		}
		return transactionPojos;
	}

	@Override
	public List<TransactionPojo> getAllMyaccTransactions(long accountId) {
		List<TransactionEntity> transactionEntities = transactionRepository.findTransactionsByAccount(accountId);

		if (transactionEntities.isEmpty()) {
			throw new TransactionNotFoundException("No transactions found!");
		}

		List<TransactionPojo> transactionPojos = new ArrayList<TransactionPojo>();

		for (TransactionEntity transactionEntity : transactionEntities) {
			TransactionPojo transactionPojo = new TransactionPojo();
			
			AccountEntity accountEntity = transactionEntity.getAccount();
			AccountPojo accountPojo = new AccountPojo();			
			BeanUtils.copyProperties(accountEntity, accountPojo);

			BeanUtils.copyProperties(transactionEntity, transactionPojo);
			transactionPojo.setAccount(accountPojo);

			transactionPojos.add(transactionPojo);
		}
		return transactionPojos;
	}

}
