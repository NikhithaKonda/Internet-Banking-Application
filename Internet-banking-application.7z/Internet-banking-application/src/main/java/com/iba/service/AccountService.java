package com.iba.service;

import java.util.List;
import java.util.Set;

import com.iba.entity.AccountEntity;
import com.iba.entity.SavingAccountEntity;
import com.iba.pojo.AccountPojo;
import com.iba.pojo.SavingAccountPojo;
import com.iba.pojo.TermAccountPojo;
import com.iba.pojo.TransactionPojo;

public interface AccountService {

	

	public AccountPojo TransferMoney(long accountId, long receiverId, double amount, String username, String password)throws Exception;
    
	public AccountPojo withdraw(long accountId, double amount, String username, String password) throws Exception;
    
	public AccountPojo deposit(long accountId, double amount);    		
	
	public SavingAccountPojo addSavingsAccount(SavingAccountPojo savingaccount);
	
	public TermAccountPojo addTermAccount(TermAccountPojo termaccount );
	
	public SavingAccountPojo updateSavingAccount(SavingAccountPojo updatedSavingAccount);
	
	public TermAccountPojo updateTermAccount(TermAccountPojo updatedTermAccount);
	
	public List<AccountPojo> deleteSavingAccount(long accountId);			
	
	public List<AccountPojo> deleteTermAccount(long accountId);
	
	public AccountPojo getAccount(long accountId);
	
	public List<AccountPojo> listAllAccounts() ;
	
	public List<SavingAccountPojo> listAllSavingsAccounts();
	
	public List<TermAccountPojo> listAllTermAccounts();
	
}
