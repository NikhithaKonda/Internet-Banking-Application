package com.iba.pojo;

import java.util.List;

import javax.validation.constraints.NotBlank;

public class SavingAccountPojo extends AccountPojo {

	private double minBalance;

	private double fine;

	public SavingAccountPojo() {
		super();
		// TODO Auto-generated constructor stub
	}

	public SavingAccountPojo(long accountId, @NotBlank(message = "interest cannot be blank") double interestRate,
			@NotBlank(message = "balance cannot be blank") double balance, String dateOfJoining, long customer,
			int isActive, int accountType, List<BeneficiaryPojo> beneficiaries, List<TransactionPojo> transactions,
			List<NomineePojo> nominees, double minBalance, double fine) {
		super(accountId, interestRate, balance, dateOfJoining, customer, isActive, accountType, beneficiaries,
				transactions, nominees);
		this.minBalance = minBalance;
		this.fine = fine;
	}

	public double getMinBalance() {
		return minBalance;
	}

	public void setMinBalance(double minBalance) {
		this.minBalance = minBalance;
	}

	public double getFine() {
		return fine;
	}

	public void setFine(double fine) {
		this.fine = fine;
	}

	@Override
	public String toString() {
		return "SavingAccountPojo [minBalance=" + minBalance + ", fine=" + fine + "]";
	}

}
