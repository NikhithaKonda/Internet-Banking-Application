package com.iba.pojo;

import javax.validation.constraints.NotBlank;

public class BeneficiaryPojo {

	private long beneficiaryId;

	private String beneficiaryName;

	private long beneficiaryAccountNumber;

	private String ifsc;

	private String accountType;

	private AccountPojo account;

	private int isActive;

	public BeneficiaryPojo() {
		super();
		// TODO Auto-generated constructor stub
	}

	public BeneficiaryPojo(long beneficiaryId, String beneficiaryName, long beneficiaryAccountNumber, String ifsc,
			String accountType, AccountPojo account, int isActive) {
		super();
		this.beneficiaryId = beneficiaryId;
		this.beneficiaryName = beneficiaryName;
		this.beneficiaryAccountNumber = beneficiaryAccountNumber;
		this.ifsc = ifsc;
		this.accountType = accountType;
		this.account = account;
		this.isActive = isActive;
	}

	public int getIsActive() {
		return isActive;
	}

	public void setIsActive(int isActive) {
		this.isActive = isActive;
	}

	public long getBeneficiaryId() {
		return beneficiaryId;
	}

	public void setBeneficiaryId(long beneficiaryId) {
		this.beneficiaryId = beneficiaryId;
	}

	public String getBeneficiaryName() {
		return beneficiaryName;
	}

	public void setBeneficiaryName(String beneficiaryName) {
		this.beneficiaryName = beneficiaryName;
	}

	public long getBeneficiaryAccountNumber() {
		return beneficiaryAccountNumber;
	}

	public void setBeneficiaryAccountNumber(long beneficiaryAccountNumber) {
		this.beneficiaryAccountNumber = beneficiaryAccountNumber;
	}

	public String getIfsc() {
		return ifsc;
	}

	public void setIfsc(String ifsc) {
		this.ifsc = ifsc;
	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	public AccountPojo getAccount() {
		return account;
	}

	public void setAccount(AccountPojo account) {
		this.account = account;
	}

	@Override
	public String toString() {
		return "BeneficiaryPojo [beneficiaryId=" + beneficiaryId + ", beneficiaryName=" + beneficiaryName
				+ ", beneficiaryAccountNumber=" + beneficiaryAccountNumber + ", ifsc=" + ifsc + ", accountType="
				+ accountType + ", account=" + account + ", isActive=" + isActive + "]";
	}

}
