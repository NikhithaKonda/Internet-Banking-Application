package com.iba.pojo;

public class TransactionJson {
	
	private long accountId;
	
	private long receiverAccountId;
	
	private double amount;
	
	private String username;
	
	private String password;

	public TransactionJson() {
		super();
		// TODO Auto-generated constructor stub
	}


	public TransactionJson(long accountId, long receiverAccountId, double amount, String username, String password) {
		super();
		this.accountId = accountId;
		this.receiverAccountId = receiverAccountId;
		this.amount = amount;
		this.username = username;
		this.password = password;
	}


	public long getAccountId() {
		return accountId;
	}

	public void setAccountId(long accountId) {
		this.accountId = accountId;
	}

	public long getReceiverAccountId() {
		return receiverAccountId;
	}

	public void setReceiverAccountId(long receiverAccountId) {
		this.receiverAccountId = receiverAccountId;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}



	public String getUsername() {
		return username;
	}


	public void setUsername(String username) {
		this.username = username;
	}


	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}


	@Override
	public String toString() {
		return "TransactionJson [accountId=" + accountId + ", receiverAccountId=" + receiverAccountId + ", amount="
				+ amount + ", username=" + username + ", password=" + password + "]";
	}



	

}
