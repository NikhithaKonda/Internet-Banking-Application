package com.iba.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.iba.entity.CustomerEntity;
import com.iba.entity.UserEntity;



@Repository
public interface CustomerRepository extends JpaRepository<CustomerEntity, Long> {
	
	
	@Query(
			value = "SELECT u FROM CustomerEntity u WHERE u.userId = :userId"
		)
	 CustomerEntity findCustomerByUserId(@Param("userId")long userId);
	
	@Query(
		value = "SELECT * FROM ACCOUNT u WHERE u.ACCOUNT_ID = ?1",
		nativeQuery = true
	)
	List<CustomerEntity> findTransactionsByAccount(long accountId);
	
//	@Query(value = "SELECT * FROM customer c JOIN users u on c.user_id = u.user_id WHERE u.user_name = :username", nativeQuery = true)
//	public List<CustomerEntity> findByUserName(@Param("username") String username);
	
	@Query(value = "SELECT u FROM UserEntity u WHERE u.username = :username")
	UserEntity findByUserName(@Param("username") String username);
	
//	@Query(value = "SELECT c FROM CustomerEntity c WHERE( SELECT u. ) ")
//	CustomerEntity findByUserName(@Param("username") String username);
}
