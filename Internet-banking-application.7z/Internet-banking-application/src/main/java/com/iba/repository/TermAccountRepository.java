package com.iba.repository;

import org.springframework.stereotype.Repository;

@Repository
public interface TermAccountRepository extends AccountRepository {
	
}
