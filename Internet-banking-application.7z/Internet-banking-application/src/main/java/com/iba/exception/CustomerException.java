package com.iba.exception;

public class CustomerException {

}
