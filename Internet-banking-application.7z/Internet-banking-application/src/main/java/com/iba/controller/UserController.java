package com.iba.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.iba.config.JwtUtil;
import com.iba.entity.AuthRequest;
import com.iba.entity.AuthResponce;
import com.iba.entity.UserEntity;
import com.iba.pojo.UserPojo;
import com.iba.service.UserSevice;

@RestController
@CrossOrigin
@RequestMapping
public class UserController {
	
	@Autowired
	public UserSevice userSevice;
	
	@Autowired
	private AuthenticationManager authenticationManager;
	
	@Autowired
	private JwtUtil jwtUtil;
	
	
	@PostMapping("/authenticate")
	public ResponseEntity<?> createAuthenticationToken(@RequestBody AuthRequest authRequest) throws Exception {
		System.out.println(authRequest.getUsername() + " " + authRequest.getPassword());
		try {
			authenticationManager.authenticate(
					new UsernamePasswordAuthenticationToken(authRequest.getUsername(), authRequest.getPassword())
					);			
		} catch(BadCredentialsException e) {
			throw new Exception("Incorrect username or password!", e);
		}catch(Exception e) {
			throw new Exception("auth manager failed!" + e);
		}
		
		final UserDetails userDetails = userSevice.loadUserByUsername(authRequest.getUsername());

		final String token = jwtUtil.generateToken(userDetails);
		
		UserEntity userEntity = userSevice.getByUserName(authRequest.getUsername());
		UserPojo user = new UserPojo();
		user.setUserId(userEntity.getUserId());
		user.setUsername(userDetails.getUsername());
		user.setPassword(userDetails.getPassword());
		user.setType(userEntity.getType());
		
		return ResponseEntity.ok(new AuthResponce(token, user));
	}
	
	@PostMapping("/register")
	public ResponseEntity<?> registerUser(@RequestBody UserPojo entity) throws Exception {
		return ResponseEntity.ok(userSevice.saveUser(entity));
	}
	
	@GetMapping("/all")
	public List<UserPojo> getAllUsers() {
		return userSevice.ListAllUsers();
	}
	
	@PostMapping("/create")
	public UserPojo addUser(@Valid @RequestBody UserPojo user) {
		return userSevice.addNewUser(user);
	}

	@PutMapping("/create")
	public UserPojo updateUser(@Valid @RequestBody UserPojo user) {
		return userSevice.updateUserInfo(user);
	}
	
	@GetMapping("/{id}")
	public UserPojo getUserById(@PathVariable("id") long userId) {
		return userSevice.getUserById(userId);
	}
	
	@GetMapping("/signin")
	public boolean signIn(@RequestParam(value = "id") long userid,@RequestParam(value = "password") String password) {
		return userSevice.signIn(userid, password);
	}

}
