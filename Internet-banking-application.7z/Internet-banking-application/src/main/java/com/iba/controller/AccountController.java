package com.iba.controller;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.iba.entity.AccountEntity;
import com.iba.entity.SavingAccountEntity;
import com.iba.pojo.AccountPojo;
import com.iba.pojo.SavingAccountPojo;
import com.iba.pojo.TermAccountPojo;
import com.iba.pojo.TransactionJson;
import com.iba.pojo.TransactionPojo;
import com.iba.service.AccountService;

@RestController
@CrossOrigin
@RequestMapping("/account")
public class AccountController {
	
	@Autowired
	private AccountService accountService;
	
	@GetMapping("/all")
	public List<AccountPojo> getAllAccounts(){
		return accountService.listAllAccounts();
	}
	

	@PostMapping("/savingsaccount")
    public SavingAccountPojo addSavingsAccount(@RequestBody SavingAccountPojo savingsaccount) {
		return accountService.addSavingsAccount(savingsaccount);
    
	}
	
	
	@PostMapping("/termaccount")
	public TermAccountPojo addTermAccount(@RequestBody TermAccountPojo termaccount ) {
		return accountService.addTermAccount(termaccount);
		
	}
	
	
	@PutMapping("/savingaccount")
	public SavingAccountPojo updateSavingAccount(@RequestBody SavingAccountPojo updatedSavingAccount) {
		return accountService.updateSavingAccount(updatedSavingAccount);
	}
	
	@PutMapping("/termaccount")
	public TermAccountPojo updateTermAccount(@RequestBody TermAccountPojo updatedTermAccount) {
		return accountService.updateTermAccount(updatedTermAccount);
	}
	
	@GetMapping("/get/{id}")
	public AccountPojo getAccountById(@PathVariable("id") long accountId) {
		return accountService.getAccount(accountId);
	}
	
	
	@PutMapping("/savingsaccount/{accountId}")
	public List<AccountPojo> deleteSavingAccount(@PathVariable("accountId") long accountId) {
	return accountService.deleteSavingAccount(accountId);	
	}
	
	
	@PutMapping("/termaccount/{accountId}")
	public List<AccountPojo> deleteTermAccount(@PathVariable("accountId") long accountId) {
		return accountService.deleteTermAccount(accountId);
		
	}
	
	@GetMapping("/{accountId}")
	public AccountPojo getAccount(@PathVariable("accountId") long accountId) {
		return accountService.getAccount(accountId);
	}
	
	@GetMapping("/account")
	public List<AccountPojo> getlistAllAccounts() {
		return accountService.listAllAccounts();
	}
	
	@GetMapping("/savingaccount")
	public List<SavingAccountPojo> getlistAllSavingsAccounts() {
		return accountService.listAllSavingsAccounts();
	}
	
	@GetMapping("/termaccount")
	public List<TermAccountPojo> getlistAllTermAccounts(){
		return accountService.listAllTermAccounts();
	}
	
	@PutMapping("/deposit/{accountId}/{amount}")
	public AccountPojo deposit(@PathVariable long accountId, @PathVariable double amount) {
		return accountService.deposit(accountId, amount);
	}
	
	@PutMapping("/withdraw")
	public AccountPojo withdraw(@RequestBody TransactionJson object ) throws Exception {
		
		long accountId = object.getAccountId();
		double amount = object.getAmount();
		String username = object.getUsername();
		String password = object.getPassword();
		
		return accountService.withdraw(accountId, amount, username, password);
		
	}
	@PutMapping("/transfer")
	public AccountPojo TransferMoney(@RequestBody TransactionJson object ) throws Exception {
		
		long accountId = object.getAccountId();
		double amount = object.getAmount();
		String username = object.getUsername();
		String password = object.getPassword();
		long receiverId = object.getReceiverAccountId();
		
		return accountService.TransferMoney(accountId, receiverId, amount, username, password);
		
	}


}
